<?php

namespace App\Controllers;

class Produk extends BaseController
{
    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        $data['produk'] = session()->get('products') ?? [];

        return view('produk/index', $data);
    }

    public function tambah()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        return view('produk/tambah');
    }

    public function create()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        $nama = trim($this->request->getPost('nama') ?? '');
        $harga = trim($this->request->getPost('harga') ?? '');
        $stok = trim($this->request->getPost('stok') ?? '');

        if ($nama === '' || $harga === '' || $stok === '') {
            return redirect()->back()->with('error', 'Semua data menu wajib diisi.');
        }

        $products = session()->get('products') ?? [];
        $products[] = [
            'nama' => $nama,
            'harga' => (int) $harga,
            'stok' => (int) $stok,
        ];

        session()->set('products', $products);

        return redirect()->to('/produk');
    }
}
