<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        $data = [
            'username' => session()->get('username'),
            'role' => session()->get('role'),
            'produk' => session()->get('products') ?? [],
        ];

        return view('dashboard', $data);
    }
}
