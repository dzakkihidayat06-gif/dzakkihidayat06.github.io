<?php

namespace App\Controllers;

class Auth extends BaseController
{
    public function login()
    {
        return view('auth/login');
    }

    public function showRegister()
    {
        return view('auth/register');
    }

    public function register()
    {
        $username = trim($this->request->getPost('username') ?? '');
        $password = trim($this->request->getPost('password') ?? '');

        if ($username === '' || $password === '') {
            return redirect()->back()->with('error', 'Username dan password wajib diisi.');
        }

        $users = session()->get('users') ?? [];
        $users[$username] = [
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'role' => 'user',
        ];

        session()->set('users', $users);
        session()->set([
            'id' => uniqid('user_', true),
            'username' => $username,
            'role' => 'user',
            'logged_in' => true,
        ]);

        return redirect()->to('/dashboard');
    }

    public function proses_login()
    {
        $username = trim($this->request->getPost('username') ?? '');
        $password = trim($this->request->getPost('password') ?? '');

        $users = session()->get('users') ?? [];

        if ($username === 'admin' && $password === 'admin') {
            session()->set([
                'id' => 1,
                'username' => 'admin',
                'role' => 'admin',
                'logged_in' => true,
            ]);

            return redirect()->to('/dashboard');
        }

        if (isset($users[$username]) && password_verify($password, $users[$username]['password'])) {
            session()->set([
                'id' => uniqid('user_', true),
                'username' => $username,
                'role' => $users[$username]['role'],
                'logged_in' => true,
            ]);

            return redirect()->to('/dashboard');
        }

        return redirect()->back()->with('error', 'Username atau password salah.');
    }

    public function logout()
    {
        session()->destroy();

        return redirect()->to('/login');
    }
}
