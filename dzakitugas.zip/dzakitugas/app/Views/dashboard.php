<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Kantin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark p-3">
    <div class="container">
        <a class="navbar-brand" href="/dashboard">Kantin Digital</a>
        <a href="/logout" class="btn btn-danger">Keluar</a>
    </div>
</nav>

<div class="container mt-5">
    <h2>Halo, <?= esc($username) ?>!</h2>

    <?php if ($role === 'admin'): ?>
        <div class="alert alert-info">
            Anda login sebagai <strong>ADMIN</strong>. Anda memiliki akses penuh untuk mengelola menu.
            <br>
            <a href="/produk/tambah" class="btn btn-primary mt-2">Tambah Menu Baru</a>
        </div>
    <?php else: ?>
        <div class="alert alert-success">
            Anda login sebagai <strong>USER</strong>. Silakan pilih menu yang tersedia.
        </div>
    <?php endif; ?>

    <div class="card mt-4">
        <div class="card-body">
            <h5 class="card-title">Menu yang tersedia</h5>
            <?php if (!empty($produk)): ?>
                <ul class="list-group mt-3">
                    <?php foreach ($produk as $item): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                                <strong><?= esc($item['nama']) ?></strong><br>
                                <small>Stok: <?= (int) $item['stok'] ?></small>
                            </div>
                            <span class="badge bg-primary">Rp <?= number_format((int) $item['harga'], 0, ',', '.') ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <div class="alert alert-secondary mt-3 mb-0">Belum ada menu yang ditambahkan.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

</body>
</html>
