<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Produk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-dark bg-dark p-3">
    <div class="container">
        <a class="navbar-brand" href="/dashboard">Kantin Digital</a>
        <a href="/logout" class="btn btn-danger">Keluar</a>
    </div>
</nav>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Daftar Menu</h3>
        <a href="/produk/tambah" class="btn btn-primary">Tambah Menu</a>
    </div>
    <?php if (!empty($produk)): ?>
        <div class="list-group">
            <?php foreach ($produk as $item): ?>
                <div class="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-1"><?= esc($item['nama']) ?></h6>
                        <small>Stok: <?= (int) $item['stok'] ?></small>
                    </div>
                    <span class="badge bg-success">Rp <?= number_format((int) $item['harga'], 0, ',', '.') ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-secondary">Belum ada menu.</div>
    <?php endif; ?>
</div>
</body>
</html>
